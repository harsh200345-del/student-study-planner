/**
 * Student Study Planner - Interactive Frontend Engine
 */

let currentFilter = 'all';
let currentSubject = 'all';
let searchKeyword = '';
let searchTimeout = null;
let donutChart = null;
let barChart = null;

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    initDateDisplay();
    setDefaultDueDate();
    loadAllData();
});

// Update current date in header
function initDateDisplay() {
    const now = new Date();
    const options = { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' };
    const dateStr = now.toLocaleDateString('en-US', options);
    const dateEl = document.getElementById('currentDateDisplay');
    if (dateEl) dateEl.textContent = dateStr;
}

// Set default task due date to today in input field
function setDefaultDueDate() {
    const today = new Date().toISOString().split('T')[0];
    const dueInput = document.getElementById('taskDueDateInput');
    if (dueInput) dueInput.value = today;
}

// Master reload function
async function loadAllData() {
    await Promise.all([
        loadStats(),
        loadSubjects(),
        loadTasks()
    ]);
    if (window.lucide) {
        lucide.createIcons();
    }
}

// ==================== DASHBOARD STATS & CHARTS ====================

async function loadStats() {
    try {
        const res = await fetch('/api/dashboard/stats');
        const data = await res.json();

        // Metric Cards
        document.getElementById('statTotalTasks').textContent = data.total_tasks;
        document.getElementById('statPendingTasks').textContent = data.pending_tasks;
        document.getElementById('statCompletedTasks').textContent = `${data.completed_tasks} / ${data.total_tasks}`;
        document.getElementById('statRate').textContent = `${data.completion_rate}%`;
        document.getElementById('statProgressBar').style.width = `${data.completion_rate}%`;

        document.getElementById('statTodayCompleted').textContent = data.today_completed;
        document.getElementById('statTodayTotal').textContent = data.today_total;
        document.getElementById('badgeTodayCount').textContent = data.today_total;
        
        const remainingToday = data.today_total - data.today_completed;
        document.getElementById('statTodayRemainingText').textContent = 
            remainingToday > 0 ? `${remainingToday} tasks left today` : (data.today_total > 0 ? 'All done today! 🎉' : 'No tasks today');

        document.getElementById('statHoursCompleted').textContent = data.study_hours_completed;
        document.getElementById('statHoursPlanned').textContent = data.study_hours_planned;

        // Overdue Alert Banner
        const alertBanner = document.getElementById('overdueAlertBanner');
        const overdueCount = document.getElementById('overdueCountText');
        if (data.overdue_tasks > 0) {
            alertBanner.classList.remove('hidden');
            overdueCount.textContent = data.overdue_tasks;
        } else {
            alertBanner.classList.add('hidden');
        }

        // Render Charts
        renderDonutChart(data);
        renderBarChart(data.subjects);

    } catch (err) {
        console.error('Error loading dashboard stats:', err);
    }
}

function renderDonutChart(stats) {
    const ctx = document.getElementById('taskStatusChart');
    if (!ctx) return;

    if (donutChart) {
        donutChart.destroy();
    }

    const hasData = stats.total_tasks > 0;
    const dataValues = hasData ? [stats.completed_tasks, stats.pending_tasks, stats.overdue_tasks] : [0, 0, 1];
    const labels = hasData ? ['Completed', 'Pending', 'Overdue'] : ['No Tasks'];
    const colors = hasData ? ['#10b981', '#6366f1', '#f43f5e'] : ['#e2e8f0'];

    donutChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: dataValues,
                backgroundColor: colors,
                borderWidth: 2,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '72%',
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        boxWidth: 10,
                        font: { size: 11 },
                        padding: 12
                    }
                }
            }
        }
    });
}

function renderBarChart(subjects) {
    const ctx = document.getElementById('subjectBarChart');
    if (!ctx) return;

    if (barChart) {
        barChart.destroy();
    }

    if (!subjects || subjects.length === 0) return;

    const labels = subjects.map(s => s.name.length > 14 ? s.name.substring(0, 12) + '...' : s.name);
    const completedData = subjects.map(s => s.completed);
    const pendingData = subjects.map(s => s.pending);

    barChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Done',
                    data: completedData,
                    backgroundColor: '#10b981',
                    borderRadius: 4
                },
                {
                    label: 'Pending',
                    data: pendingData,
                    backgroundColor: '#6366f1',
                    borderRadius: 4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: { stacked: true, grid: { display: false }, ticks: { font: { size: 10 } } },
                y: { stacked: true, beginAtZero: true, ticks: { stepSize: 1, font: { size: 10 } } }
            },
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { boxWidth: 10, font: { size: 11 }, padding: 10 }
                }
            }
        }
    });
}

// ==================== SUBJECTS ====================

async function loadSubjects() {
    try {
        const res = await fetch('/api/subjects');
        const subjects = await res.json();

        // Update Task Modal select dropdown
        const modalSelect = document.getElementById('taskSubjectInput');
        const filterSelect = document.getElementById('subjectFilterSelect');
        const currentSelectedFilter = filterSelect.value;

        modalSelect.innerHTML = '<option value="" disabled selected>Select Subject</option>';
        filterSelect.innerHTML = '<option value="all">All Subjects</option>';

        subjects.forEach(sub => {
            // Task modal dropdown
            const opt1 = document.createElement('option');
            opt1.value = sub.id;
            opt1.textContent = sub.name;
            modalSelect.appendChild(opt1);

            // Filter dropdown
            const opt2 = document.createElement('option');
            opt2.value = sub.id;
            opt2.textContent = sub.name;
            if (String(sub.id) === String(currentSelectedFilter)) opt2.selected = true;
            filterSelect.appendChild(opt2);
        });

        // Render Subjects in Right Column
        const container = document.getElementById('subjectListContainer');
        if (subjects.length === 0) {
            container.innerHTML = `
                <div class="text-center py-6 text-slate-400 text-xs">
                    No subjects yet. Click "+ Add New" to start!
                </div>
            `;
            return;
        }

        container.innerHTML = subjects.map(sub => `
            <div class="p-3 rounded-xl border border-slate-100 hover:border-slate-200 transition bg-slate-50/50">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-2">
                        <span class="w-3 h-3 rounded-full" style="background-color: ${sub.color}"></span>
                        <span class="text-xs font-bold text-slate-800">${escapeHtml(sub.name)}</span>
                    </div>
                    <div class="flex items-center space-x-2">
                        <span class="text-[11px] font-semibold text-slate-500">${sub.completed_tasks}/${sub.total_tasks}</span>
                        <button onclick="handleDeleteSubject(${sub.id}, '${escapeHtml(sub.name)}')" title="Delete Subject" class="text-slate-300 hover:text-rose-500 transition">
                            <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                        </button>
                    </div>
                </div>
                <!-- Progress bar -->
                <div class="w-full bg-slate-200/70 rounded-full h-1 mt-2 overflow-hidden">
                    <div class="h-1 rounded-full transition-all duration-300" style="width: ${sub.completion_rate}%; background-color: ${sub.color}"></div>
                </div>
                ${sub.description ? `<p class="text-[10px] text-slate-400 mt-1.5 truncate">${escapeHtml(sub.description)}</p>` : ''}
            </div>
        `).join('');

    } catch (err) {
        console.error('Error loading subjects:', err);
    }
}

async function handleCreateSubject(e) {
    e.preventDefault();
    const name = document.getElementById('subjectNameInput').value.trim();
    const color = document.getElementById('subjectColorInput').value;
    const description = document.getElementById('subjectDescInput').value.trim();

    try {
        const res = await fetch('/api/subjects', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, color, description })
        });
        const data = await res.json();
        if (!res.ok) {
            showToast(data.error || 'Failed to create subject', true);
            return;
        }

        showToast('Subject created successfully!');
        closeSubjectModal();
        document.getElementById('subjectForm').reset();
        await loadAllData();
    } catch (err) {
        showToast('Network error while creating subject', true);
    }
}

async function handleDeleteSubject(id, name) {
    if (!confirm(`Are you sure you want to delete "${name}"? All associated tasks will also be deleted.`)) {
        return;
    }

    try {
        const res = await fetch(`/api/subjects/${id}`, { method: 'DELETE' });
        if (res.ok) {
            showToast(`Subject "${name}" deleted.`);
            if (currentSubject == id) currentSubject = 'all';
            await loadAllData();
        } else {
            showToast('Failed to delete subject', true);
        }
    } catch (err) {
        showToast('Error deleting subject', true);
    }
}

// ==================== TASKS ====================

async function loadTasks() {
    try {
        let url = `/api/tasks?filter=${encodeURIComponent(currentFilter)}`;
        if (currentSubject && currentSubject !== 'all') {
            url += `&subject_id=${encodeURIComponent(currentSubject)}`;
        }
        if (searchKeyword) {
            url += `&search=${encodeURIComponent(searchKeyword)}`;
        }

        const res = await fetch(url);
        const tasks = await res.json();
        renderTasks(tasks);
    } catch (err) {
        console.error('Error loading tasks:', err);
    }
}

function renderTasks(tasks) {
    const container = document.getElementById('taskListContainer');

    if (tasks.length === 0) {
        container.innerHTML = `
            <div class="text-center py-16 bg-white rounded-2xl border border-slate-200/80 p-6 space-y-3">
                <div class="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                    <i data-lucide="check-check" class="w-6 h-6"></i>
                </div>
                <h4 class="text-sm font-bold text-slate-700">No tasks found</h4>
                <p class="text-xs text-slate-400 max-w-sm mx-auto">
                    ${searchKeyword ? 'No tasks matched your search query.' : 'You have no study tasks in this view. Enjoy your free time or add a new study goal!'}
                </p>
                <button onclick="openTaskModal()" class="inline-flex items-center space-x-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition">
                    <i data-lucide="plus" class="w-3.5 h-3.5"></i>
                    <span>Create a Task</span>
                </button>
            </div>
        `;
        if (window.lucide) lucide.createIcons();
        return;
    }

    container.innerHTML = tasks.map(task => {
        const isDone = task.is_completed;
        const statusBadgeClass = `status-badge-${task.status}`;
        
        // Friendly deadline format
        const deadlineLabel = formatDeadline(task.due_date, task.due_time, task.status);

        return `
            <div class="task-card bg-white p-4 rounded-xl border border-slate-200/80 flex items-start space-x-3.5 ${isDone ? 'task-completed' : ''}" id="task-${task.id}">
                <!-- Checkbox -->
                <div class="pt-0.5">
                    <input type="checkbox" ${isDone ? 'checked' : ''} 
                           onchange="handleToggleTask(${task.id})" 
                           class="custom-checkbox" title="Mark as completed">
                </div>

                <!-- Task Details -->
                <div class="flex-1 min-w-0 space-y-1">
                    <div class="flex flex-wrap items-center gap-1.5 mb-1">
                        <!-- Subject Pill -->
                        <span class="inline-flex items-center space-x-1 px-2 py-0.5 rounded-md text-[11px] font-semibold text-white shadow-xs" style="background-color: ${task.subject_color}">
                            <span>${escapeHtml(task.subject_name)}</span>
                        </span>

                        <!-- Deadline Pill -->
                        <span class="px-2 py-0.5 rounded-md text-[11px] font-medium ${statusBadgeClass} flex items-center space-x-1">
                            <i data-lucide="calendar" class="w-3 h-3 mr-0.5"></i>
                            <span>${deadlineLabel}</span>
                        </span>

                        <!-- Priority Pill -->
                        <span class="px-2 py-0.5 rounded-md text-[11px] font-semibold priority-${task.priority}">
                            ${task.priority}
                        </span>

                        <!-- Duration Pill -->
                        <span class="px-2 py-0.5 rounded-md text-[11px] font-medium bg-slate-100 text-slate-600 flex items-center space-x-1">
                            <i data-lucide="clock-3" class="w-3 h-3 mr-0.5"></i>
                            <span>${task.duration_mins}m</span>
                        </span>
                    </div>

                    <!-- Title -->
                    <h3 class="task-title text-sm font-semibold text-slate-800 leading-snug">
                        ${escapeHtml(task.title)}
                    </h3>

                    <!-- Description / Notes -->
                    ${task.description ? `
                        <p class="text-xs text-slate-500 pt-0.5 leading-relaxed">
                            ${escapeHtml(task.description)}
                        </p>
                    ` : ''}
                </div>

                <!-- Actions -->
                <div class="shrink-0 flex items-center space-x-1">
                    <button onclick="handleDeleteTask(${task.id})" title="Delete task" class="p-1 text-slate-300 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition">
                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                    </button>
                </div>
            </div>
        `;
    }).join('');

    if (window.lucide) {
        lucide.createIcons();
    }
}

async function handleCreateTask(e) {
    e.preventDefault();

    const title = document.getElementById('taskTitleInput').value.trim();
    const subject_id = document.getElementById('taskSubjectInput').value;
    const priority = document.getElementById('taskPriorityInput').value;
    const due_date = document.getElementById('taskDueDateInput').value;
    const due_time = document.getElementById('taskDueTimeInput').value;
    const duration_mins = parseInt(document.getElementById('taskDurationInput').value, 10);
    const description = document.getElementById('taskDescInput').value.trim();

    if (!title || !subject_id || !due_date) {
        showToast('Please fill out all required fields', true);
        return;
    }

    try {
        const res = await fetch('/api/tasks', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                title, subject_id, priority, due_date, due_time, duration_mins, description
            })
        });

        const data = await res.json();
        if (!res.ok) {
            showToast(data.error || 'Failed to add task', true);
            return;
        }

        showToast('Study task added!');
        closeTaskModal();
        document.getElementById('taskForm').reset();
        setDefaultDueDate();
        await loadAllData();
    } catch (err) {
        showToast('Network error while adding task', true);
    }
}

async function handleToggleTask(id) {
    try {
        const res = await fetch(`/api/tasks/${id}/toggle`, { method: 'PUT' });
        const data = await res.json();
        if (res.ok) {
            showToast(data.is_completed ? 'Task completed! Keep it up! 🎯' : 'Task marked as pending.');
            await loadAllData();
        } else {
            showToast('Failed to update task', true);
        }
    } catch (err) {
        showToast('Error updating task', true);
    }
}

async function handleDeleteTask(id) {
    if (!confirm('Are you sure you want to delete this study task?')) return;

    try {
        const res = await fetch(`/api/tasks/${id}`, { method: 'DELETE' });
        if (res.ok) {
            showToast('Task removed.');
            await loadAllData();
        } else {
            showToast('Failed to delete task', true);
        }
    } catch (err) {
        showToast('Error deleting task', true);
    }
}

// ==================== FILTERING & SEARCH ====================

function setFilter(filter) {
    currentFilter = filter;
    
    // Update active UI tab
    document.querySelectorAll('.filter-btn').forEach(btn => {
        if (btn.getAttribute('data-filter') === filter) {
            btn.classList.add('active-filter');
        } else {
            btn.classList.remove('active-filter');
        }
    });

    loadTasks();
}

function applySubjectFilter(subId) {
    currentSubject = subId;
    loadTasks();
}

function debounceSearch() {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
        searchKeyword = document.getElementById('searchInput').value.trim();
        loadTasks();
    }, 250);
}

// ==================== DATE FORMATTING HELPERS ====================

function formatDeadline(dateStr, timeStr, status) {
    const today = new Date().toISOString().split('T')[0];
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

    const timeFormatted = timeStr ? formatTime(timeStr) : '';

    if (dateStr === today) {
        return `Today ${timeFormatted}`.trim();
    } else if (dateStr === tomorrow) {
        return `Tomorrow ${timeFormatted}`.trim();
    } else if (dateStr === yesterday) {
        return `Yesterday (Overdue)`;
    } else {
        const d = new Date(dateStr + 'T00:00:00');
        const formattedDate = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        return `${formattedDate} ${timeFormatted}`.trim();
    }
}

function formatTime(timeStr) {
    const [h, m] = timeStr.split(':');
    let hours = parseInt(h, 10);
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;
    return `${hours}:${m} ${ampm}`;
}

// ==================== MODALS & TOAST ====================

function openTaskModal() {
    document.getElementById('taskModal').classList.remove('hidden');
    document.getElementById('taskTitleInput').focus();
}

function closeTaskModal() {
    document.getElementById('taskModal').classList.add('hidden');
}

function openSubjectModal() {
    document.getElementById('subjectModal').classList.remove('hidden');
    document.getElementById('subjectNameInput').focus();
}

function closeSubjectModal() {
    document.getElementById('subjectModal').classList.add('hidden');
}

function selectPresetColor(hex) {
    document.getElementById('subjectColorInput').value = hex;
}

function showToast(message, isError = false) {
    const toast = document.getElementById('toastNotification');
    const toastMsg = document.getElementById('toastMessage');
    const toastIcon = document.getElementById('toastIcon');

    toastMsg.textContent = message;
    if (isError) {
        toastIcon.setAttribute('data-lucide', 'alert-circle');
        toastIcon.classList.remove('text-emerald-400');
        toastIcon.classList.add('text-rose-400');
    } else {
        toastIcon.setAttribute('data-lucide', 'check-circle-2');
        toastIcon.classList.remove('text-rose-400');
        toastIcon.classList.add('text-emerald-400');
    }

    if (window.lucide) lucide.createIcons();

    toast.classList.remove('translate-y-20', 'opacity-0');
    toast.classList.add('translate-y-0', 'opacity-100');

    setTimeout(() => {
        toast.classList.add('translate-y-20', 'opacity-0');
        toast.classList.remove('translate-y-0', 'opacity-100');
    }, 2800);
}

// Simple HTML escaping helper
function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g, "&amp;")
              .replace(/</g, "&lt;")
              .replace(/>/g, "&gt;")
              .replace(/"/g, "&quot;")
              .replace(/'/g, "&#039;");
}
